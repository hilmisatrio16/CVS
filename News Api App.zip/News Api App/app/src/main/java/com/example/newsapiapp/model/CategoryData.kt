package com.example.newsapiapp.model

data class CategoryData(
    var name : String,
    var image : String
)