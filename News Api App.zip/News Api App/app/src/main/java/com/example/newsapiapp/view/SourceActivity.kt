package com.example.newsapiapp.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.newsapiapp.R
import com.example.newsapiapp.databinding.ActivitySourceBinding
import com.example.newsapiapp.model.article.Source
import com.example.newsapiapp.view.adapter.SourceAdapter
import com.example.newsapiapp.viewmodel.SourceViewModel

class SourceActivity : AppCompatActivity() {
    lateinit var binding: ActivitySourceBinding
    lateinit var sourceAdapter: SourceAdapter
    lateinit var sourceViewModel: SourceViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySourceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sourceAdapter = SourceAdapter(ArrayList())

        sourceViewModel = ViewModelProvider(this).get(SourceViewModel::class.java)

        setRecycleView()
    }

    private fun setRecycleView() {
        binding.rvSource.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        binding.rvSource.adapter = sourceAdapter

        val bundle = intent.extras
        val getCategori = bundle?.getString("category", "").toString()

        sourceViewModel.callApiSource(getCategori)

        sourceViewModel.getDataSource().observe(this, Observer {
            sourceAdapter.setListSource(it)
        })
    }
}