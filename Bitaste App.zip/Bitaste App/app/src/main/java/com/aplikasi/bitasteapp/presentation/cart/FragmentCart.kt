package com.aplikasi.bitasteapp.presentation.cart

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.aplikasi.bitasteapp.R
import com.aplikasi.bitasteapp.databinding.FragmentCartBinding


@Suppress("DEPRECATION")
class FragmentCart : Fragment() {

    lateinit var binding: FragmentCartBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentCartBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.ivBackCart.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.bottom_ic_home -> {
                    // Navigasi ke FragmentHome
                    findNavController().navigate(R.id.fragmentHome)
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.bottom_ic_profile -> {
                // Navigasi ke FragmentProfile
                findNavController().navigate(R.id.fragmentProfile)
                return@setOnNavigationItemSelectedListener true
                }

                else -> false
            }

        }

    }


}