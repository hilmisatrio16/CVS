package com.aplikasi.bitasteapp.presentation.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class CartViewModel : ViewModel () {
    fun getCart(){
        viewModelScope.launch {  }
    }
}